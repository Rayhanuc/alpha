/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_termmeta` VALUES
(1,10,"thumbnail","85"),
(2,10,"_thumbnail","field_5c9cbf0d0131e"),
(3,11,"thumbnail","113"),
(4,11,"_thumbnail","field_5c9cbf0d0131e"),
(5,28,"language_featured_image","a:1:{s:14:\"featured_image\";s:3:\"273\";}"),
(6,27,"language_featured_image","a:1:{s:14:\"featured_image\";s:3:\"282\";}");
