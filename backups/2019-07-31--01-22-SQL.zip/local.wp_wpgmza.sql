/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_wpgmza` VALUES
(1,1,"California","","","","","36.778261","-119.4179323999","0","","","",1,0,0,"","","\0\0\0\0\0\0\0J`s�cB@�`�g��]�");
