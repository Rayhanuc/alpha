/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_users` VALUES
(1,"alpha","$P$BT1xnAm5v52j4vhPpbr12h728F3pMC1","alpha","rayhanctg4@gmail.com","","2019-02-15 14:47:23","",0,"philosophy"),
(2,"Test user","$P$BV6wrM88YR7UUmuEgd2OZXPbaA85hI/","test-user","test@mail.com","http://test.com","2019-03-28 13:44:10","1553780650:$P$BlkMUqgFipiYelV.Xq.B66lbvmlr.B1",0,"Test User");
