/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_comments` VALUES
(1,1,"A WordPress Commenter","wapuu@wordpress.example","https://wordpress.org/","","2019-02-15 14:47:23","2019-02-15 14:47:23","Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.",0,"1","","",0,0),
(2,33,"philosophy","rayhanctg4@gmail.com","","127.0.0.1","2019-04-14 09:04:27","2019-04-14 09:04:27","Hi",0,"1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36","",0,1),
(3,33,"philosophy","rayhanctg4@gmail.com","","127.0.0.1","2019-04-14 09:05:24","2019-04-14 09:05:24","This is my second comment.",0,"1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36","",2,1),
(4,33,"philosophy","rayhanctg4@gmail.com","","127.0.0.1","2019-04-14 09:07:24","2019-04-14 09:07:24","Something in this comment.",0,"1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36","",0,1),
(5,1,"philosophy","rayhanctg4@gmail.com","","127.0.0.1","2019-04-14 09:22:09","2019-04-14 09:22:09","What a comment. Wow!",0,"1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36","",0,1),
(6,1,"philosophy","rayhanctg4@gmail.com","","127.0.0.1","2019-04-14 09:22:40","2019-04-14 09:22:40","Amazing comment! Wow.",0,"1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36","",0,1),
(7,1,"philosophy","rayhanctg4@gmail.com","","127.0.0.1","2019-04-14 09:24:00","2019-04-14 09:24:00","Another Beautiful comment. :)",0,"1","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36","",0,1);
